<?php
session_start();
include 'db.php'; // Kết nối database

// Xử lý đăng nhập
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send2'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password, role FROM customer WHERE email = ?");
    if ($stmt === false) {
        die("Lỗi prepare: " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    if (!$stmt->execute()) {
        die("Lỗi execute: " . $stmt->error);
    }
    $stmt->store_result();
    $stmt->bind_result($stored_password, $role);

    if ($stmt->fetch() && $password === $stored_password) {
        $_SESSION['email'] = $email;
        $_SESSION['role'] = $role;
        header("Location: Home.php");
        exit();
    } else {
        $error = "Email hoặc mật khẩu không đúng!";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webleb</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
        integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="type.css?v=1">
</head>
<body style="display: flex; align-items: center; justify-content: center; min-height: 100vh;">
    <div class="login-page">
        <div class="form">
            <form class="register-form" method="POST" action="signup.php">
                <h2><i class="fas fa-lock"></i> Register</h2>
                <?php
                if (isset($_GET['signup_error'])) {
                    echo '<p style="color: red; text-align: center;">' . htmlspecialchars($_GET['signup_error']) . '</p>';
                }
                if (isset($_GET['signup_success'])) {
                    echo '<p style="color: green; text-align: center;">Đăng ký thành công! Vui lòng đăng nhập.</p>';
                }
                ?>
                <input type="email" name="email" placeholder="Email *" required/>
                <input type="password" name="password" placeholder="Password *" required/>
                <input type="password" name="confirm_password" placeholder="Confirm Password *" required/>
                <button type="submit">create</button>
                <p class="message">Already registered? <a href="#" class="switch-to-login">Sign In</a></p>
            </form>
            <form class="login-form" method="POST" action="">
                <h2><i class="fas fa-lock"></i> Login</h2>
                <?php if (isset($error)) { echo '<p style="color: red; text-align: center;">' . htmlspecialchars($error) . '</p>'; } ?>
                <input type="email" name="email" placeholder="Email" required/>
                <input type="password" name="password" placeholder="Password" required/>
                <button type="submit" name="send2">login</button>
                <p class="message">Not registered? <a href="#" class="switch-to-register">Create an account</a></p>
            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="main.js"></script>
</body>
</html>