<?php
session_start();
include 'db.php'; // Kết nối database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Kiểm tra mật khẩu khớp
    if ($password !== $confirm_password) {
        die("Mật khẩu không khớp! <a href='Login.php'>Quay lại</a>");
    }

    // Kiểm tra email đã tồn tại
    $check_stmt = $conn->prepare("SELECT email FROM customer WHERE email = ?");
    if ($check_stmt === false) {
        die("Lỗi prepare (check): " . $conn->error . " <a href='Login.php'>Quay lại</a>");
    }
    $check_stmt->bind_param("s", $email);
    if (!$check_stmt->execute()) {
        die("Lỗi execute (check): " . $check_stmt->error . " <a href='Login.php'>Quay lại</a>");
    }
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        die("Email đã được sử dụng! <a href='Login.php'>Quay lại</a>");
    }
    $check_stmt->close();

    // Chèn dữ liệu vào bảng customer
    $role = 'customer'; // Mặc định là customer
    $stmt = $conn->prepare("INSERT INTO customer (email, password, role) VALUES (?, ?, ?)");
    if ($stmt === false) {
        die("Lỗi prepare (insert): " . $conn->error . " <a href='Login.php'>Quay lại</a>");
    }
    $stmt->bind_param("sss", $email, $password, $role);
    if ($stmt->execute()) {
        echo "Đăng ký thành công! Đang chuyển hướng...";
        header("Refresh: 2; url=Login.php?signup_success=1");
        exit();
    } else {
        die("Lỗi execute (insert): " . $stmt->error . " <a href='Login.php'>Quay lại</a>");
    }
    $stmt->close();
}
$conn->close();
?>