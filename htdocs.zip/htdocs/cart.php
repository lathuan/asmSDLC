<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_cart'])) {
    $product = [
        'name' => $_POST['product_name'],
        'price' => $_POST['product_price'],
        'description' => $_POST['product_description'],
        'stock' => $_POST['product_stock'],
        'image' => $_POST['product_image'],
        'quantity' => 1
    ];

    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['name'] === $product['name']) {
            $item['quantity'] += 1;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $_SESSION['cart'][] = $product;
    }

    header("Location: cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="type.css">
    <style>
        .cart-table { width: 80%; margin: 20px auto; border-collapse: collapse; }
        .cart-table th, .cart-table td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        .cart-table th { background-color: #f2f2f2; }
        .cart-table img { max-width: 100px; }
    </style>
</head>
<body>
    <h1>Giỏ Hàng</h1>
    <?php if (empty($_SESSION['cart'])) { ?>
        <p style="text-align: center;">Chưa có sản phẩm trong giỏ hàng.</p>
    <?php } else { ?>
        <table class="cart-table">
            <tr>
                <th>Hình ảnh</th>
                <th>Tên sản phẩm</th>
                <th>Mô tả</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Tổng</th>
            </tr>
            <?php
            $total = 0;
            foreach ($_SESSION['cart'] as $item) {
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
            ?>
                <tr>
                    <td><img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>"></td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['description']); ?></td>
                    <td><?php echo number_format($item['price'], 2); ?> VND</td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td><?php echo number_format($subtotal, 2); ?> VND</td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="5" style="text-align: right;"><strong>Tổng cộng:</strong></td>
                <td><?php echo number_format($total, 2); ?> VND</td>
            </tr>
        </table>
    <?php } ?>
    <p style="text-align: center;"><a href="Home.php">Quay lại trang chủ</a></p>
</body>
</html>