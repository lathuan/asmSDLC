<?php
session_start();

$host = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecommerce"; // Đổi nếu tên database khác

$conn = new mysqli($host, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION['email'] = $email;
        header("Location: Home.php");
        exit();
    } else {
        header("Location: Home.php?error=1");
        exit();
    }

    $stmt->close();
}

$conn->close();
?>