<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: Home.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $ten_san_pham = $_POST['ten_san_pham'];
    $mo_ta = $_POST['mo_ta'];
    $gia = $_POST['gia'];
    $so_luong_ton_kho = $_POST['so_luong_ton_kho'];
    $category_id = $_POST['category_id'];

    // Xử lý upload ảnh
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/"; // Thư mục lưu ảnh
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true); // Tạo thư mục nếu chưa có
        }
        
        $file_name = basename($_FILES['image']['name']);
        $target_file = $target_dir . time() . "_" . $file_name; // Thêm timestamp để tránh trùng tên
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                // Thêm sản phẩm vào database
                $stmt = $conn->prepare("INSERT INTO product (ten_san_pham, mo_ta, gia, so_luong_ton_kho, category_id, image) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt === false) {
                    die("Lỗi prepare: " . $conn->error);
                }
                $stmt->bind_param("ssdiss", $ten_san_pham, $mo_ta, $gia, $so_luong_ton_kho, $category_id, $target_file);

                if ($stmt->execute()) {
                    $success = "Thêm sản phẩm thành công!";
                } else {
                    $error = "Có lỗi khi thêm sản phẩm vào database!";
                    unlink($target_file); // Xóa file nếu insert thất bại
                }
                $stmt->close();
            } else {
                $error = "Lỗi khi upload ảnh!";
            }
        } else {
            $error = "Chỉ chấp nhận file ảnh JPG, JPEG, PNG, GIF!";
        }
    } else {
        $error = "Vui lòng chọn file ảnh!";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="type.css">
    <style>
        .form-container { width: 50%; margin: 50px auto; padding: 20px; border: 1px solid #ccc; }
        .form-container input, .form-container select { width: 100%; padding: 10px; margin: 10px 0; }
        .form-container button { background-color: #D4AF37; color: #1A1A1A; padding: 10px; border: none; cursor: pointer; }
        .form-container button:hover { background-color: #FF5151; color: #fff; }
    </style>
</head>
<body>
    <h1>Thêm Sản Phẩm Mới</h1>
    <div class="form-container">
        <?php 
        if ($error) { echo "<p style='color: red;'>$error</p>"; }
        if ($success) { echo "<p style='color: green;'>$success</p>"; }
        ?>
        <form action="admin_add_product.php" method="POST" enctype="multipart/form-data">
            <label>Tên sản phẩm:</label>
            <input type="text" name="ten_san_pham" required>
            <label>Mô tả:</label>
            <input type="text" name="mo_ta" required>
            <label>Giá (VND):</label>
            <input type="number" name="gia" step="0.01" required>
            <label>Số lượng tồn kho:</label>
            <input type="number" name="so_luong_ton_kho" required>
            <label>Danh mục:</label>
            <select name="category_id" required>
                <?php
                $conn = new mysqli("localhost", "root", "", "ecommerce");
                $result = $conn->query("SELECT * FROM category");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['category_id']}'>{$row['category_name']}</option>";
                }
                $conn->close();
                ?>
            </select>
            <label>Ảnh sản phẩm:</label>
            <input type="file" name="image" accept="image/*" required>
            <button type="submit" name="add_product">Thêm Sản Phẩm</button>
        </form>
        <p><a href="Home.php">Quay lại trang chủ</a></p>
    </div>
</body>
</html>