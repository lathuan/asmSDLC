<?php if ($_SESSION['role'] === 'admin') { ?>
    <a href="admin_add_product.php">Add Product</a>
    <a href="admin_users.php">Manage Users</a>
<?php } ?>