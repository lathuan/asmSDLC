<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: Login.php");
    exit();
}

include 'db.php';

// Xóa sản phẩm
if (isset($_GET['delete']) && $_SESSION['role'] === 'admin') {
    $product_id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM product WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();
    header("Location: Home.php");
    exit();
}

// Xóa khách hàng
if (isset($_GET['delete_customer']) && $_SESSION['role'] === 'admin') {
    $customer_id = $_GET['delete_customer'];
    if ($customer_id != $_SESSION['customer_id']) { // Ngăn admin xóa chính mình, nếu có customer_id trong session
        $stmt = $conn->prepare("DELETE FROM customer WHERE customer_id = ?");
        $stmt->bind_param("i", $customer_id);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: Home.php");
    exit();
}

// Lấy danh sách sản phẩm
$sql_products = "SELECT p.*, c.ten_danh_muc FROM product p JOIN category c ON p.category_id = c.category_id";
$result_products = $conn->query($sql_products);

if ($result_products === false) {
    die("SQL query error (products): " . $conn->error);
}

// Lấy danh sách khách hàng (chỉ dành cho admin)
$sql_customers = "SELECT customer_id, email, role FROM customer"; // Sử dụng customer_id thay vì id
$result_customers = $conn->query($sql_customers);

if ($result_customers === false) {
    die("SQL query error (customers): " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
    <title>OriStar - Luxury Jewelry</title>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <h1>OriStar</h1>
            </div>
            <nav class="nav-menu">
                <a href="Home.php">Home</a>
                <a href="#">Products</a>
                <a href="#">Contact</a>
                <?php if ($_SESSION['role'] === 'admin') { ?>
                    <a href="admin_add_product.php">Add Product</a>
                <?php } ?>
            </nav>
            <div class="user-menu">
                <span class="welcome-text">Hello, <?php echo htmlspecialchars($_SESSION['email']); ?></span>
                <a href="cart.php" class="cart-icon"><ion-icon name="cart-outline"></ion-icon> Cart</a>
                <a href="logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </header>

    <main>
        <div class="slideshow-container">
            <div class="slide fade">
                <img src="https://cdn.pnj.io/images/promo/244/tabsale-t4-25-1972x640CTA.jpg" alt="Advertisement 1" onerror="this.src='https://via.placeholder.com/1200x400?text=Slide+1'">
                <div class="slide-text">Premium Gold Jewelry - OriStar</div>
            </div>
            <div class="slide fade">
                <img src="https://cdn.pnj.io/images/promo/244/ngaydoi-44-1972x640-cta.jpg" alt="Advertisement 2" onerror="this.src='https://via.placeholder.com/1200x400?text=Slide+2'">
                <div class="slide-text">Eternal Diamonds - OriStar</div>
            </div>
            <div class="slide fade">
                <img src="https://cdn.pnj.io/images/promo/240/giao-3h-t3-25-1972x640apdungCTA.jpg" alt="Advertisement 3" onerror="this.src='https://via.placeholder.com/1200x400?text=Slide+3'">
                <div class="slide-text">Elegant Pearls - OriStar</div>
            </div>
            <a class="prev" onclick="plusSlides(-1)">❮</a>
            <a class="next" onclick="plusSlides(1)">❯</a>
        </div>

        <div class="container">
            <h2 class="section-title">Featured Products</h2>
            <div class="products-wrapper">
                <?php
                if ($result_products->num_rows > 0) {
                    while ($row = $result_products->fetch_assoc()) {
                        ?>
                        <article class="card">
                            <div class="card__img">
                                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['ten_san_pham']); ?>">
                            </div>
                            <div class="card__content">
                                <h3 class="card__name"><?php echo htmlspecialchars($row['ten_san_pham']); ?></h3>
                                <p class="card__category"><?php echo htmlspecialchars($row['ten_danh_muc']); ?></p>
                                <p class="card__description"><?php echo htmlspecialchars($row['mo_ta']); ?></p>
                                <span class="card__price"><?php echo number_format($row['gia'], 0); ?> VND</span>
                                <form action="cart.php" method="POST">
                                    <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($row['ten_san_pham']); ?>">
                                    <input type="hidden" name="product_price" value="<?php echo $row['gia']; ?>">
                                    <input type="hidden" name="product_description" value="<?php echo htmlspecialchars($row['mo_ta']); ?>">
                                    <input type="hidden" name="product_stock" value="<?php echo $row['so_luong_ton_kho']; ?>">
                                    <input type="hidden" name="product_image" value="<?php echo htmlspecialchars($row['image']); ?>">
                                    <button type="submit" name="add_to_cart" class="card__button">Add to Cart</button>
                                </form>
                                <?php if ($_SESSION['role'] === 'admin') { ?>
                                    <a href="Home.php?delete=<?php echo $row['product_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                                <?php } ?>
                            </div>
                        </article>
                        <?php
                    }
                } else {
                    echo '<p class="no-products">No products in stock.</p>';
                }
                ?>
            </div>

            <?php if ($_SESSION['role'] === 'admin') { ?>
                <h2 class="section-title">Registered Customers</h2>
                <?php if ($result_customers->num_rows > 0) { ?>
                    <table class="user-table">
                        <thead>
                            <tr>
                                <th>Customer ID</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result_customers->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['customer_id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['role']); ?></td>
                                    <td>
                                        <a href="Home.php?delete_customer=<?php echo $row['customer_id']; ?>" 
                                           class="remove-btn" 
                                           onclick="return confirm('Are you sure you want to remove this customer?');">Remove</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } else { ?>
                    <p class="no-users">No registered customers found.</p>
                <?php } ?>
            <?php } ?>
        </div>
    </main>

    <footer>
        <div class="footer-container">
            <p>© 2025 OriStar. All rights reserved.</p>
            <p>Contact: contact@oriststar.com | 0123-456-789</p>
        </div>
    </footer>

    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
    <script>
        let slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function showSlides(n) {
            let slides = document.getElementsByClassName("slide");
            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }
            for (let i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slides[slideIndex-1].style.display = "block";
        }

        setInterval(() => plusSlides(1), 5000);
    </script>
</body>
</html>
<?php
$conn->close();
?>